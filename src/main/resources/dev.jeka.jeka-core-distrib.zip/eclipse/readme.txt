Contains some libraries that are likely to be in Eclipse environment.
This directory is only intended for users who want Jeka extract build info from Eclipse metadata (.classpath file).

